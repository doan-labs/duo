/* @ts-self-types="./mono.d.ts" */

/**
 * The engine. `new Engine()` keeps its store in memory, and
 * `Engine.open(storage, env?)` opens the store in a host storage object (the
 * seven D9 methods, see `storage.rs`). Without an env the engine uses
 * `Date.now` and `crypto.getRandomValues`; with one (`new Engine(env)`) it uses the object's `nowMs(): number` and
 * `randomBytes(n): Uint8Array` (exactly `n` bytes). A host env that throws or
 * returns something else (a NaN clock, short random bytes) fails the request
 * that needed it with `STORAGE`, with nothing changed and nothing written.
 * The env is only asked when a request must generate an `_id`.
 */
export class Engine {
    static __wrap(ptr) {
        const obj = Object.create(Engine.prototype);
        obj.__wbg_ptr = ptr;
        EngineFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EngineFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_engine_free(ptr, 0);
    }
    /**
     * Answers one request, a plain JS value (D7, D8). The answer is
     * `{ ok: value }` or `{ error: { code, message } }`, with an `events`
     * list (a watch has a new result), oldest first, when the request queued
     * any, for the host to deliver before the answer; a request that is
     * malformed, too deep, cyclic, throws while it is read or holds a value
     * that is not data is an error answer, never a throw.
     * @param {any} request
     * @returns {any}
     */
    dispatch(request) {
        const ret = wasm.engine_dispatch(this.__wbg_ptr, addHeapObject(request));
        return takeObject(ret);
    }
    /**
     * Runs the compaction a commit left due, if any. The host calls it when
     * it is idle after it has sent an answer, so a commit never waits for
     * it; a host that never does loses nothing, since the next request that
     * writes runs it first. Does nothing while a request is running.
     */
    maintain() {
        wasm.engine_maintain(this.__wbg_ptr);
    }
    /**
     * @param {any | null} [env]
     */
    constructor(env) {
        const ret = wasm.engine_new(isLikeNone(env) ? 0 : addHeapObject(env));
        this.__wbg_ptr = ret;
        EngineFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The engine over the store in `storage`, made if there is none. Throws
     * an error answer, `{ error: { code, message } }`, when the store cannot
     * be opened: `STORAGE` for damaged files, `QUOTA`, `POOL_DRY`. The engine
     * owns the storage object until it is freed.
     * @param {any} storage
     * @param {any | null} [env]
     * @returns {Engine}
     */
    static open(storage, env) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.engine_open(retptr, addHeapObject(storage), isLikeNone(env) ? 0 : addHeapObject(env));
            var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
            var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
            var r2 = getDataViewMemory0().getInt32(retptr + 4 * 2, true);
            if (r2) {
                throw takeObject(r1);
            }
            return Engine.__wrap(r0);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
    /**
     * Internal: it exists for the spec runner, which restarts an engine in
     * place to test persistence, and is not part of the public API (the
     * TypeScript client does not expose it). Closes the engine and opens a
     * new one on the same storage, with the same env, as a host that restarts
     * the engine in place would. The answer is `{ ok: null }`, or an error if
     * the stored files cannot be opened, in which case the engine stays
     * closed. Everything committed survives (Q39), and transaction ids
     * continue, so one from before names no transaction after.
     * @returns {any}
     */
    reopen() {
        const ret = wasm.engine_reopen(this.__wbg_ptr);
        return takeObject(ret);
    }
    /**
     * Internal, for the spec runner (a case's `answerLimit`): lowers the most
     * a list answer may weigh, as a host with less memory would
     * (`Engine::set_answer_limit`). It survives `reopen`. Does nothing while
     * a request is running.
     * @param {number} bytes
     */
    setAnswerLimit(bytes) {
        wasm.engine_setAnswerLimit(this.__wbg_ptr, bytes);
    }
    /**
     * Internal, for the spec runner (a case's `replyLimit`): lowers the most
     * bytes one `read` hands out, as a host that cannot carry a larger reply
     * would (`Engine::set_read_limit`). It survives `reopen`. Does nothing
     * while a request is running.
     * @param {number} bytes
     */
    setReplyLimit(bytes) {
        wasm.engine_setReplyLimit(this.__wbg_ptr, bytes);
    }
}
if (Symbol.dispose) Engine.prototype[Symbol.dispose] = Engine.prototype.free;

/**
 * The version of the core this module was built from.
 * @returns {string}
 */
export function coreVersion() {
    let deferred1_0;
    let deferred1_1;
    try {
        const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
        wasm.coreVersion(retptr);
        var r0 = getDataViewMemory0().getInt32(retptr + 4 * 0, true);
        var r1 = getDataViewMemory0().getInt32(retptr + 4 * 1, true);
        deferred1_0 = r0;
        deferred1_1 = r1;
        return getStringFromWasm0(r0, r1);
    } finally {
        wasm.__wbindgen_add_to_stack_pointer(16);
        wasm.__wbindgen_export4(deferred1_0, deferred1_1, 1);
    }
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_boolean_get_5b446f51afd21013: function(arg0) {
            const v = getObject(arg0);
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_is_bigint_b123553bed3bb382: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_null_e343b7d08827ba72: function(arg0) {
            const ret = getObject(arg0) === null;
            return ret;
        },
        __wbg___wbindgen_is_object_3c45d4f2dde4e749: function(arg0) {
            const val = getObject(arg0);
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_90b56bc79aad6f6c: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_symbol_3acc5de2aaea59b9: function(arg0) {
            const ret = typeof(getObject(arg0)) === 'symbol';
            return ret;
        },
        __wbg___wbindgen_is_undefined_8865fb403f8fe9d8: function(arg0) {
            const ret = getObject(arg0) === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_02babf21faa37971: function(arg0, arg1) {
            const ret = getObject(arg0) === getObject(arg1);
            return ret;
        },
        __wbg___wbindgen_memory_caa4a6165639c8b5: function() {
            const ret = wasm.memory;
            return addHeapObject(ret);
        },
        __wbg___wbindgen_number_get_2e0e7dee9f701a71: function(arg0, arg1) {
            const obj = getObject(arg1);
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_0380ccaa2f57f0d9: function(arg0, arg1) {
            const obj = getObject(arg1);
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_export, wasm.__wbindgen_export2);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_41e9ee4f547fc59a: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_apply_bb00966270d2c6ad: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.apply(getObject(arg0), getObject(arg1), getObject(arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_defineProperty_70e1ec588d4573df: function(arg0, arg1, arg2, arg3) {
            Object.defineProperty(getObject(arg0), getStringFromWasm0(arg1, arg2), getObject(arg3));
        },
        __wbg_flush_9dc1ac778adfd45e: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).flush(getStringFromWasm0(arg1, arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_getOwnPropertyDescriptor_d78d4502841325ab: function() { return handleError(function (arg0, arg1) {
            const ret = Object.getOwnPropertyDescriptor(getObject(arg0), getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_getPrototypeOf_77ec0a99448ff18b: function() { return handleError(function (arg0) {
            const ret = Reflect.getPrototypeOf(getObject(arg0));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_getRandomValues_1fa8072167db25eb: function() { return handleError(function (arg0, arg1) {
            const ret = crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_3695ae77eb199a33: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(getObject(arg0), getObject(arg1));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_get_e55023a817465144: function(arg0, arg1) {
            const ret = getObject(arg0)[arg1 >>> 0];
            return addHeapObject(ret);
        },
        __wbg_hasOwn_1ab82c722bc69459: function() { return handleError(function (arg0, arg1) {
            const ret = Object.hasOwn(getObject(arg0), getObject(arg1));
            return ret;
        }, arguments); },
        __wbg_has_40fff2fd382b6297: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.has(getObject(arg0), getObject(arg1));
            return ret;
        }, arguments); },
        __wbg_instanceof_Arr_ae4d28f8c54ad599: function(arg0) {
            let result;
            try {
                result = getObject(arg0) instanceof Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_61c0f88c27af8aaf: function() { return handleError(function (arg0) {
            const ret = Array.isArray(getObject(arg0));
            return ret;
        }, arguments); },
        __wbg_length_25e41ac0f7181f0b: function(arg0) {
            const ret = getObject(arg0).length;
            return ret;
        },
        __wbg_length_54bd802a038bcc2b: function(arg0) {
            const ret = getObject(arg0).length;
            return ret;
        },
        __wbg_list_ef0c5b8bde2e7932: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).list();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_2afed8751de5efaf: function(arg0) {
            const ret = new Date(arg0);
            return addHeapObject(ret);
        },
        __wbg_new_2c03575d43f372f4: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = new Uint8Array(getObject(arg0), arg1, arg2);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_new_arr_35e9448215f6d345: function() {
            const ret = new Array();
            return addHeapObject(ret);
        },
        __wbg_new_obj_fec648d61f0e837a: function() {
            const ret = new Object();
            return addHeapObject(ret);
        },
        __wbg_nowMs_c66d40c5120d7e12: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).nowMs();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_now_9f43fde935ed5296: function() { return handleError(function () {
            const ret = Date.now();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_ownKeys_7bfc10b3b794ff2e: function() { return handleError(function (arg0) {
            const ret = Reflect.ownKeys(getObject(arg0));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_push_0cdc93001c2fcd42: function(arg0, arg1) {
            getObject(arg0).push(getObject(arg1));
        },
        __wbg_randomBytes_f676103c18de2ca1: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg0).randomBytes(arg1 >>> 0);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_readAt_eb7e7c86a9f47254: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
            const ret = getObject(arg0).readAt(getStringFromWasm0(arg1, arg2), arg3, getArrayU8FromWasm0(arg4, arg5));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_remove_bed655edb3a29597: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).remove(getStringFromWasm0(arg1, arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_reserve_067103cc81b53e9d: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = getObject(arg0).reserve(getStringFromWasm0(arg1, arg2), arg3);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_set_00c6bdb027787334: function(arg0, arg1, arg2, arg3) {
            const ret = Reflect.set(getObject(arg0), getStringFromWasm0(arg1, arg2), getObject(arg3));
            return ret;
        },
        __wbg_size_8543c1ea925b4df8: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = getObject(arg0).size(getStringFromWasm0(arg1, arg2));
            return addHeapObject(ret);
        }, arguments); },
        __wbg_slice_7472de053a970af0: function() { return handleError(function (arg0) {
            const ret = getObject(arg0).slice();
            return addHeapObject(ret);
        }, arguments); },
        __wbg_slice_a327bc18e4d6546c: function() { return handleError(function (arg0, arg1) {
            const ret = getObject(arg1).slice();
            const ptr1 = passArray8ToWasm0(ret, wasm.__wbindgen_export);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        }, arguments); },
        __wbg_static_accessor_GLOBAL_bfafd41c9226ddb1: function() {
            const ret = globalThis;
            return addHeapObject(ret);
        },
        __wbg_static_accessor_TO_STRING_TAG_3e7ba5a3f34c4acf: function() {
            const ret = Symbol.toStringTag;
            return addHeapObject(ret);
        },
        __wbg_truncate_c2f82affb36d6c8a: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = getObject(arg0).truncate(getStringFromWasm0(arg1, arg2), arg3);
            return addHeapObject(ret);
        }, arguments); },
        __wbg_writeAt_bbccfdb710e5ecd9: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4, arg5) {
            const ret = getObject(arg0).writeAt(getStringFromWasm0(arg1, arg2), arg3, getArrayU8FromWasm0(arg4, arg5));
            return addHeapObject(ret);
        }, arguments); },
        __wbindgen_generic_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return addHeapObject(ret);
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return addHeapObject(ret);
        },
        __wbindgen_object_clone_ref: function(arg0) {
            const ret = getObject(arg0);
            return addHeapObject(ret);
        },
        __wbindgen_object_drop_ref: function(arg0) {
            takeObject(arg0);
        },
    };
    return {
        __proto__: null,
        "./mono_bg.js": import0,
    };
}

const EngineFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_engine_free(ptr, 1));

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}

function dropObject(idx) {
    if (idx < 1028) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function getObject(idx) { return heap[idx]; }

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        wasm.__wbindgen_export3(addHeapObject(e));
    }
}

let heap = new Array(1024).fill(undefined);
heap.push(undefined, null, true, false);

let heap_next = heap.length;

function isLikeNone(x) {
    return x === undefined || x === null;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('mono_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
